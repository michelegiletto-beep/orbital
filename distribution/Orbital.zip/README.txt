Orbital
General library

Run node launch.mjs from the extracted directory and open http://127.0.0.1:4317. Requires Node 22 or later. No Internet connection is needed.

This local package contains only the selected library. Local exercises are not an accredited environment for classified information.

Earth imagery: NASA Earth Observatory, Blue Marble Next Generation and Blue Marble Clouds. Historical composites. No endorsement implied.

© Michele Giletto. All rights reserved for original software. Third party components retain their licenses.